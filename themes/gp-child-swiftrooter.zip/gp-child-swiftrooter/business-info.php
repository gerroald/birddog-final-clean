<?php
define('BUSINESS_NAME', 'Bird Dog\'s Delivery & Moving Services');
define('BUSINESS_PHONE', '(405) 535-4554');
define('BUSINESS_PHONE_LINK', 'tel:+14055354554');
define('BUSINESS_ADDRESS', '3509 NW 22nd St, Oklahoma City, OK 73107');
define('BUSINESS_EMAIL', 'birddogmoving@gmail.com');
define('BUSINESS_HOURS', 'Mon-Fri: 8am-5pm');
define('IS_MOVING_COMPANY', true);
?>
