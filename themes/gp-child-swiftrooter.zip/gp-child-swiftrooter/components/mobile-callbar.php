<div class="callbar" role="region" aria-label="Quick actions">
  <a class="c-button c-button--primary" href="tel:1234567890">Call Now</a>
  <a class="c-button c-button--ghost" href="<?php echo esc_url(home_url('/contact/#estimate')); ?>">Get Estimate</a>
</div>