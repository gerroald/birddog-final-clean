<!-- wp:template {"slug":"front-page"} -->
<!-- Render exactly what’s in the Home page editor -->
<!-- wp:post-content {"layout":{"type":"constrained","contentSize":"1100px"}} /-->
<!-- /wp:template -->
