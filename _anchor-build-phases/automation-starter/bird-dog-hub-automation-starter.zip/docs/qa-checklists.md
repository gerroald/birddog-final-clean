# QA Checklists

1) Publish a test post.
   - Hub freshness meta updates (if mapped)
   - IndexNow 200 (production only)
   - Slack card received (if webhook configured)
2) Remove featured image → lane-change card posts
3) Heartbeat returns `{"ok":true}`
